import sys
from pathlib import Path


def add_one():
    number = int(Path(sys.argv[1]))
    return number + 1


# def hello():
#     print("Hello, World!")
